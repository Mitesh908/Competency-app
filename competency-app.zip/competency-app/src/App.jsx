import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import CompetencyApp from './components/competencyApp';
import DetailPage from './components/detailPage.jsx';
import '../src/styles/App.css';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<CompetencyApp />} />
        <Route path="/details" element={<DetailPage />} />
      </Routes>
    </Router>
  );
}

export default App;
