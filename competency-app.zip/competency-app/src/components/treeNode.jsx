import React, { useState } from 'react';

const TreeNode = ({ label, children }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className={`tree-node ${isOpen ? 'open' : ''}`}>
      <div className="tree-node-label" onClick={handleToggle}>
        {label}
        {children && <span className="arrow">{isOpen ? '▼' : '►'}</span>}
      </div>
      {isOpen && (
        <div className="tree-children">
          <div className="child-container">
            {React.Children.map(children, (child) => (
              <div className="child-node">{child}</div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TreeNode;
