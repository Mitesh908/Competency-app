import React, { useState, useEffect } from 'react';
import Header from './header.jsx';
import data from '../data/data.json'; 
import '../styles/detailPage.css'; 
import { useLocation, useNavigate } from 'react-router-dom';

const DetailPage = () => {
    const projects = data.projects || []; 
    const benchResources = data.benchResources;
    const [selectedResources, setSelectedResources] = useState([]);
    const location = useLocation(); 
    const departmentName = location.state?.departmentName; 
    const showTable = location.state?.showTable; 
    const navigate = useNavigate(); 
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [isStatusPopupOpen, setIsStatusPopupOpen] = useState(false);
    const [selectedResource, setSelectedResource] = useState(null);
    
    const [filter, setFilter] = useState('Last 10 days');
    const [filteredRecords, setFilteredRecords] = useState([]);

    const handleResourceClick = (resources) => {
        setSelectedResources(resources);
        setIsPopupOpen(true);
    };

    const closePopup = () => {
        setIsPopupOpen(false);
        setSelectedResources([]);
        setIsStatusPopupOpen(false); 
        setSelectedResource(null);
    };

    const handleBack = () => {
        navigate(-1);
    };

    const handleStatusClick = (resource) => {
        setSelectedResource(resource);
        setIsStatusPopupOpen(true);
    };

    const handleFilterChange = (event) => {
        setFilter(event.target.value);
    };



    return (
        <div>
            <Header />
            {showTable ? (
                <div className="table-container">
                    <div className='project-heading'>
                        <button onClick={handleBack} className='back-button'>←</button>
                        <h2>{departmentName ? `${departmentName} Details` : 'Project Details'}</h2>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Project Detail</th>
                                <th>No of Resources</th>
                                <th>Technologies</th>
                            </tr>
                        </thead>
                        <tbody>
                            {projects.map((project, index) => (
                                <tr key={index}>
                                    <td>{project.projectDetail}</td>
                                    <td onClick={() => handleResourceClick(project.resources)} style={{ cursor: 'pointer', color: 'blue' }}>
                                        {project.resources.length}
                                    </td>
                                    <td>{project.technology.join(', ')}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    {isPopupOpen && (
                        <div className="popup-overlay">
                            <div className="popup-content">
                                <h3>Resources working on project:</h3>
                                <ul>
                                    {selectedResources.map((resource, index) => (
                                        <li key={index}>{resource}</li>
                                    ))}
                                </ul>
                                <button className='close-btn' onClick={closePopup}>Close</button>
                            </div>
                        </div>
                    )}
                </div>
            ) : (
                <div className="bench-details">
                    <div className='bench-heading'>
                        <button onClick={handleBack} className='back-button'>←</button>
                        <h2>{departmentName ? `${departmentName} - Bench Details` : 'Bench Details'}</h2>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Technologies</th>
                                <th>Upcoming Plans</th> 
                                <th>Status</th> 
                            </tr>
                        </thead>
                        <tbody>
                            {benchResources.map((resource, index) => (
                                <tr key={index}>
                                    <td>{resource.name}</td>
                                    <td>{resource.technologies.join(', ')}</td>
                                    <td>{resource.upcomingPlans ? resource.upcomingPlans.join(', ') : 'N/A'}</td> 
                                    <td>
                                        <button  className='view-btn' onClick={() => handleStatusClick(resource)}>View</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>

                    {isStatusPopupOpen && selectedResource && (
                        <div className="status-popup-overlay">
                            <div className="status-popup-content">
                                <h3 className="heading">Status Summary - <span className="resource-name">{selectedResource.name}</span></h3>
                                <div className="status-container">
                                    <div className="status-info">
                                        <p><span className="heading">Innovation Project:</span> <span className="text">xxx</span></p>
                                        <p><span className="heading">Demo Produced:</span> <span className="text"><a href="#">Link</a></span></p>
                                    </div>
                                    <div className="filter-container">
                                        <label htmlFor="filter">Filter:</label>
                                        <select id="filter" value={filter} onChange={handleFilterChange}>
                                            <option value="Last 10 days">Last 10 days</option>
                                            <option value="Last 20 days">Last 20 days</option>
                                            <option value="Last 30 days">Last 30 days</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="records-container">

                                {selectedResource.statusRecords
                                    .slice(0, filter === 'Last 10 days' ? 10 : filter === 'Last 20 days' ? 20 : 30)
                                    .map((record, index) => (
                                        <div key={index} className="record-card">
                                              <span className="record-date">{record.date}</span>
                                              <span className="record-summary">{record.summary}</span>
                                        </div>
                                    ))}
                                </div>
                                <button className='close-btn' onClick={closePopup}>Close</button>
                            </div>
                        </div>
                    )}
                </div>
            )}
        </div>
    );
};

export default DetailPage;
