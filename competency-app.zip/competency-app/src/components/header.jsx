import React from 'react';
import '../styles/header.css'; 
import logo from '../assets/logo.png'; 

const Header = () => {
  return (
    <div className="navbar">
      <img src={logo} alt="Logo" className="navbar-logo" />
    </div>
  );
};

export default Header;
