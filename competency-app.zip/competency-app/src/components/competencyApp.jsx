import React from 'react';
import { useNavigate } from 'react-router-dom';
import TreeNode from '../components/treeNode.jsx';
import data from '../data/data.json'; 
import Header from './header.jsx';
import starIcon from '../assets/icon.png'; 
import benchIcon from '../assets/bench.png';

const CompetencyApp = () => {
  const digitalData = data?.Digital;
  const navigate = useNavigate(); 

  const handleIconClick = (key, showTable) => {
    navigate('/details', { state: { departmentName: key, showTable } }); 
  };

  return (
    <>
      <Header />   
      <div className="digital-app">
        <h1 className="digital-heading">Digital</h1>
        <div className="tree-container">
          {digitalData && (
            <div className="sections-container">
              <div className="section digital-experience">
                {Object.entries(digitalData).map(([key, value]) => (
                  <div key={key} className="tree-node-container">
                    <TreeNode label={key}>
                      {value.map((child, index) => (
                        <TreeNode key={index} label={child.name}>
                          {child.children.map((subChild, subIndex) => (
                            <TreeNode key={subIndex} label={subChild} />
                          ))}
                        </TreeNode>
                      ))}
                    </TreeNode>
                    <img 
                      src={starIcon} 
                      alt="Project Icon" 
                      onClick={() => handleIconClick(key, true)} 
                      className="icon" 
                      style={{ cursor: 'pointer' }} 
                    />
                    <img 
                      src={benchIcon} 
                      alt="Project Icon" 
                      onClick={() => handleIconClick(key, false)} 
                      className="icon" 
                      style={{ cursor: 'pointer' }} 
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default CompetencyApp;
